import uuid



import uuid

class Note:
    def __init__(self, title, content, username="", status="в процессе", created_date=None, issue_date=None, headers=None):
        self.id = str(uuid.uuid4())  # Уникальный идентификатор
        self.title = title
        self.content = content
        self.username = username  # Убедитесь, что этот аргумент присутствует
        self.status = status
        self.created_date = created_date
        self.issue_date = issue_date
        self.headers = headers if headers is not None else []

    def to_dict(self):
        """Преобразует заметку в словарь для сохранения в БД"""
        return {
            'id': self.id,
            'username': self.username,
            'title': self.title,
            'content': self.content,
            'status': self.status,
            'created_date': self.created_date,
            'issue_date': self.issue_date,
            'headers': self.headers
        }

    def items(self):
        return {'title': self.title, 'content': self.content}.items()

    @classmethod
    def from_dict(cls, data: dict) -> 'Note':
        """Создает заметку из словаря"""
        # Убедитесь, что title и content присутствуют в data
        note = cls(data['title'], data['content'])  # Передаем title и content в конструктор
        note.id = data.get('id', str(uuid.uuid4()))  # Если ID нет, создаем новый
        note.username = data['username']
        note.contents = data['contents']
        note.headers = data['headers']
        note.status = data['status']
        note.creation_date = data['creation_date']
        note.deadline_date = data['deadline_date']
        return note

    def __str__(self):
        """Строковое представление заметки"""
        return f"""
    ID: {self.id}
    Пользователь: {self.username}
    Заголовок: {self.title}
    Содержание: {', '.join(self.contents)}
    Статус: {self.status}
    Дата создания: {self.creation_date}
    Дедлайн: {self.deadline_date}
    Заголовки: {', '.join(self.headers) if self.headers else 'нет'}
    """

    def items(self):
        return {'title': self.title, 'content': self.content}.items()

    @classmethod
    def from_dict(cls, data: dict) -> 'Note':
        """Создает заметку из словаря"""
        # Передаем title и content в конструктор
        note = cls(data['title'], data['content'])
        note.id = data.get('id', str(uuid.uuid4()))  # Если ID нет, создаем новый
        note.username = data['username']
        note.contents = data['contents']
        note.headers = data['headers']
        note.status = data['status']
        note.creation_date = data['creation_date']
        note.deadline_date = data['deadline_date']
        return note

    def delete_by_header(self, header: str) -> bool:
        """Удаляет заголовок из заметки"""
        if header in self.headers:
            self.headers.remove(header)
            return True
        return False

    def matches_username(self, username: str) -> bool:
        """Проверяет, принадлежит ли заметка указанному пользователю"""
        return self.username.lower() == username.lower()
