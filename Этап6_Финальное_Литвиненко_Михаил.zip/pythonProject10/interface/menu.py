import sqlite3
from datetime import datetime
import uuid

class Note:
    def __init__(self, title, content, username="", status="в процессе", created_date=None, issue_date=None, headers=None):
        self.id = str(uuid.uuid4())  # Уникальный идентификатор
        self.title = title
        self.content = content
        self.username = username
        self.status = status
        self.created_date = created_date if created_date else datetime.now().strftime("%d.%m.%Y")
        self.issue_date = issue_date
        self.headers = headers if headers is not None else []

    def to_dict(self):
        """Преобразует заметку в словарь для сохранения в БД"""
        return {
            'id': self.id,
            'username': self.username,
            'title': self.title,
            'content': self.content,
            'status': self.status,
            'created_date': self.created_date,
            'issue_date': self.issue_date,
            'headers': self.headers
        }

class DatabaseManager:
    def __init__(self, db_path):
        self.db_path = db_path

    def connect(self):
        """Подключение к базе данных"""
        self.connection = sqlite3.connect(self.db_path)
        self.cursor = self.connection.cursor()
        self.create_table()  # Создаем таблицу при подключении

    def create_table(self):
        """Создание таблицы notes, если она не существует"""
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS notes (
                id TEXT PRIMARY KEY,
                username TEXT NOT NULL,
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                status TEXT NOT NULL,
                created_date TEXT NOT NULL,
                issue_date TEXT
            );
        """)
        self.connection.commit()

    def disconnect(self):
        """Отключение от базы данных"""
        self.connection.close()

    def save_note_to_db(self, note):
        """Сохранение заметки в базе данных"""
        self.cursor.execute("""
            INSERT INTO notes (id, username, title, content, status, created_date, issue_date)
            VALUES (?, ?, ?, ?, ?, ?, ?);
        """, (note['id'], note['username'], note['title'], note['content'], note['status'], note['created_date'], note['issue_date']))
        self.connection.commit()

    def get_all_notes(self):
        """Получение всех заметок"""
        self.cursor.execute("SELECT * FROM notes;")
        return self.cursor.fetchall()

    def get_note_by_id(self, note_id):
        """Получение заметки по ID"""
        self.cursor.execute("SELECT * FROM notes WHERE id = ?;", (note_id,))
        result = self.cursor.fetchone()
        if result:
            return {
                'id': result[0],
                'username': result[1],
                'title': result[2],
                'content': result[3],
                'status': result[4],
                'created_date': result[5],
                'issue_date': result[6]
            }
        return None

    def print_all_notes(self):
        """Печать всех заметок"""
        notes = self.get_all_notes()
        for note in notes:
            print(note)

    def update_note_in_db(self, note_id, updates):
        """Обновляет указанное поле заметки"""
        self.cursor.execute("""
            UPDATE notes
            SET title = ?, content = ?, status = ?, issue_date = ?
            WHERE id = ?;
        """, (updates['title'], updates['content'], updates['status'], updates['issue_date'], note_id))
        self.connection.commit()

    def delete_note_from_db(self, note_id):
        """Удаляет заметку по её ID"""
        self.cursor.execute("DELETE FROM notes WHERE id = ?;", (note_id,))
        self.connection.commit()  # Убедитесь, что изменения фиксируются
        print(f"Заметка с ID {note_id} была удалена.")  # Отладочная информация

    def search_notes_by_keyword(self, keyword):
        """Ищет заметки, где ключевое слово встречается в title или content"""
        self.cursor.execute("""
            SELECT * FROM notes
            WHERE title LIKE ? OR content LIKE ?;
        """, (f"%{keyword}%", f"%{keyword}%"))

        rows = self.cursor.fetchall()
        return [{'id': row[0], 'username': row[1], 'title': row[2], 'content': row[3], 'status': row[4], 'created_date': row[5], 'issue_date': row[6]} for row in rows]

    def filter_notes_by_status(self, status):
        """Возвращает заметки с указанным статусом"""
        self.cursor.execute("SELECT * FROM notes WHERE status = ?;", (status,))
        rows = self.cursor.fetchall()
        return [{'id': row[0], 'username': row[1], 'title': row[2], 'content': row[3], 'status': row[4], 'created_date': row[5], 'issue_date': row[6]} for row in rows]

def main():
    db_path = 'path_to_your_database.db'  # Укажите путь к вашей базе данных
    db = DatabaseManager(db_path)

    try:
        db.connect()  # Подключаемся к базе данных

        while True:
            print("\nМеню:")
            print("1. Добавить заметку")
            print("2. Просмотреть все заметки")
            print("3. Найти заметку по ID")
            print("4. Обновить заметку")
            print("5. Удалить заметку")
            print("6. Поиск заметок по ключевому слову")
            print("7. Фильтрация заметок по статусу")
            print("8. Выход")

            choice = input("\nВыберите действие (1-8): ")

            if choice == "1":
                # Создание новой заметки
                title = input("Введите заголовок заметки: ").strip()
                content = input("Введите содержание заметки: ").strip()
                username = input("Введите имя пользователя: ").strip()
                status = input("Введите статус (в процессе/выполнено/отложено): ").strip()
                created_date = datetime.now().strftime("%d.%m.%Y")
                issue_date = input("Введите дату выполнения (дд.мм.гггг): ").strip()
                headers = [h.strip() for h in input("Введите заголовки через запятую: ").split(',')]

                # Создание экземпляра Note
                new_note = Note(
                    title=title,
                    content=content,
                    username=username,
                    status=status,
                    created_date=created_date,
                    issue_date=issue_date,
                    headers=headers
                )

                # Сохранение заметки в базе данных
                db.save_note_to_db(new_note.to_dict())  # Сохраняем заметку в БД
                print("Заметка успешно добавлена")

            elif choice == "2":
                notes = db.get_all_notes()  # Получаем все заметки
                if notes:
                    db.print_all_notes()
                else:
                    print("Заметок пока нет")

            elif choice == "3":
                note_id = input("Введите ID заметки: ")
                note = db.get_note_by_id(note_id)
                if note:
                    print("\nНайденная заметка:")
                    print("=" * 50)
                    for key, value in note.items():
                        print(f"{key}: {value}")
                    print("=" * 50)
                else:
                    print(f"Заметка с ID {note_id} не найдена")

            elif choice == "4":
                note_id = input("Введите ID заметки для обновления: ")
                updates = {
                    'title': input("Введите новый заголовок заметки: ").strip(),
                    'content': input("Введите новое содержание заметки: ").strip(),
                    'status': input("Введите новый статус (в процессе/выполнено/отложено): ").strip(),
                    'issue_date': input("Введите новую дату выполнения (дд.мм.гггг): ").strip()
                }
                db.update_note_in_db(note_id, updates)
                print("Заметка успешно обновлена")

            elif choice == "5":
                note_id = input("Введите ID заметки для удаления: ")
                db.delete_note_from_db(note_id)
                print("Заметка успешно удалена")

                # Проверка, была ли заметка действительно удалена
                if db.get_note_by_id(note_id) is None:
                    print(f"Заметка с ID {note_id} успешно удалена из базы данных.")
                else:
                    print(f"Ошибка: Заметка с ID {note_id} все еще существует.")

            elif choice == "6":
                keyword = input("Введите ключевое слово для поиска: ")
                results = db.search_notes_by_keyword(keyword)
                if results:
                    print("\nНайденные заметки:")
                    for note in results:
                        print(f"ID: {note['id']}, Title: {note['title']}, Content: {note['content']}")
                else:
                    print("Заметок не найдено по данному ключевому слову.")

            elif choice == "7":
                status = input("Введите статус для фильтрации (в процессе/выполнено/отложено): ")
                results = db.filter_notes_by_status(status)
                if results:
                    print("\nНайденные заметки с указанным статусом:")
                    for note in results:
                        print(f"ID: {note['id']}, Title: {note['title']}, Content: {note['content']}")
                else:
                    print("Заметок не найдено с данным статусом.")

            elif choice == "8":
                print("Программа завершена")
                break

            else:
                print("Неверный выбор. Попробуйте снова")

    except Exception as e:
        print(f"Произошла ошибка: {e}")

    finally:
        db.disconnect()  # Закрываем соединение с базой данных


if __name__ == "__main__":
    main()