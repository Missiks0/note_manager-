import sqlite3
from typing import List, Optional
import os
from datetime import datetime
from data.note import Note  # Импортируем класс Note


class DatabaseManager:
    def __init__(self):
        self.db_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'notes.db')
        self.connection = None
        self.cursor = None

    def connect(self):
        """Подключение к базе данных"""
        if self.connection is not None:
            print("Уже подключено к базе данных.")
            return

        try:
            self.connection = sqlite3.connect(self.db_path)
            self.connection.execute("PRAGMA foreign_keys = ON")  # Включаем поддержку внешних ключей
            self.cursor = self.connection.cursor()
            print(f"Подключение к базе данных успешно: {self.db_path}")
        except sqlite3.Error as e:
            print(f"Ошибка подключения к базе данных: {e}")
            raise

    def save_note_to_db(self, note: dict) -> bool:
        """
        Сохраняет заметку в базу данных

        Args:
            note (dict): Словарь с данными заметки
        Returns:
            bool: True если сохранение успешно, False в случае ошибки
        """
        if not self.connection:
            print("Нет подключения к базе данных")
            return False

        try:
            # Проверяем существование таблицы
            self.cursor.execute("""
                CREATE TABLE IF NOT EXISTS notes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT NOT NULL,
                    title TEXT NOT NULL,
                    content TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_date TEXT NOT NULL,
                    issue_date TEXT NOT NULL
                )
            """)

            self.cursor.execute("""
                CREATE TABLE IF NOT EXISTS headers (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    note_id INTEGER NOT NULL,
                    header_text TEXT NOT NULL,
                    FOREIGN KEY (note_id) REFERENCES notes(id) ON DELETE CASCADE
                )
            """)

            # Вставляем данные в таблицу notes
            self.cursor.execute("""
                INSERT INTO notes (
                    username, 
                    title, 
                    content, 
                    status, 
                    created_date, 
                    issue_date
                ) VALUES (?, ?, ?, ?, ?, ?)
            """, (
                note['username'],
                note['title'],
                note['content'],
                note['status'],
                note['created_date'],
                note['issue_date']
            ))

            # Получаем ID созданной заметки
            note_id = self.cursor.lastrowid

            # Если есть заголовки, сохраняем их
            if 'headers' in note and note['headers']:
                for header in note['headers']:
                    if header.strip():  # Проверяем, что заголовок не пустой
                        self.cursor.execute("""
                            INSERT INTO headers (note_id, header_text)
                            VALUES (?, ?)
                        """, (note_id, header.strip()))

            # Сохраняем изменения
            self.connection.commit()
            print(f"Заметка успешно сохранена с ID: {note_id}")
            return True

        except sqlite3.Error as e:
            print(f"Ошибка при сохранении заметки: {e}")
            if self.connection:
                self.connection.rollback()  # Откатываем изменения в случае ошибки
            return False

    def disconnect(self):
        """Отключение от базы данных"""
        if self.connection:
            self.connection.close()
            self.connection = None  # Обнуляем соединение
            print("Соединение с базой данных закрыто")

    def get_all_notes(self) -> List[Note]:
        """Получение всех заметок из базы данных"""
        try:
            self.cursor.execute("""
                SELECT n.*, GROUP_CONCAT(h.header_text) as headers
                FROM notes n
                LEFT JOIN headers h ON n.id = h.note_id
                GROUP BY n.id
            """)

            notes = []
            for row in self.cursor.fetchall():
                note = Note()
                note.id = row[0]
                note.username = row[1]
                note.title = row[2]
                note.contents = [row[3]]  # content преобразуем в список contents
                note.status = row[4]
                note.creation_date = row[5]
                note.deadline_date = row[6]

                # Обработка заголовков
                headers_str = row[7]
                note.headers = headers_str.split(',') if headers_str else []

                notes.append(note)

            return notes
        except sqlite3.Error as e:
            print(f"Ошибка при получении заметок: {e}")
            return []

    def get_note_by_id(self, note_id: int) -> Optional[Note]:
        """Получение заметки по ID"""
        try:
            self.cursor.execute("""
                SELECT n.*, GROUP_CONCAT(h.header_text) as headers
                FROM notes n
                LEFT JOIN headers h ON n.id = h.note_id
                WHERE n.id = ?
                GROUP BY n.id
            """, (note_id,))

            row = self.cursor.fetchone()
            if row:
                note = Note()
                note.id = row[0]
                note.username = row[1]
                note.title = row[2]
                note.contents = [row[3]]
                note.status = row[4]
                note.creation_date = row[5]
                note.deadline_date = row[6]

                headers_str = row[7]
                note.headers = headers_str.split(',') if headers_str else []

                return note
            return None
        except sqlite3.Error as e:
            print(f"Ошибка при получении заметки: {e}")
            return None

    def print_all_notes(self):
        """Вывод всех заметок в консоль"""
        notes = self.get_all_notes()
        if not notes:
            print("Заметок не найдено")
            return

        for note in notes:
            print("\n" + "=" * 50)
            print(f"ID: {note.id}")
            print(f"Пользователь: {note.username}")
            print(f"Заголовок: {note.title}")
            print(f"Содержание: {', '.join(note.contents)}")
            print(f"Статус: {note.status}")
            print(f"Дата создания: {note.creation_date}")
            print(f"Дедлайн: {note.deadline_date}")
            print("Заголовки:", ', '.join(note.headers) if note.headers else "нет")
            print("=" * 50)