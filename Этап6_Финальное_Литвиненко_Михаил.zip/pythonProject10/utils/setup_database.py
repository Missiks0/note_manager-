import sqlite3
from sqlite3 import Error
import os
from datetime import datetime

# Устанавливаем кодировку UTF-8 для Windows
import sys

if sys.platform.startswith('win'):
    sys.stdout.reconfigure(encoding='utf-8')

# Получаем абсолютный путь к директории проекта
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATABASE_PATH = os.path.join(PROJECT_ROOT, 'notes.db')


def create_connection():
    """Создает соединение с базой данных"""
    try:
        connection = sqlite3.connect(DATABASE_PATH)
        # Устанавливаем кодировку UTF-8 для базы данных
        connection.execute('PRAGMA encoding = "UTF-8"')
        print(f"Успешное подключение к SQLite версии {sqlite3.version}")
        return connection
    except Error as e:
        print(f"Ошибка при подключении к SQLite: {e}")
        return None

def dict_factory(cursor, row):
    """Преобразует строки БД в словари"""
    d = {}
    for idx, col in enumerate(cursor.description):
        d[col[0]] = row[idx]
    return d

def create_tables(connection):
    """Создает необходимые таблицы если они не существуют"""
    try:
        cursor = connection.cursor()

        # Удаляем старые таблицы, если они существуют
        cursor.execute("DROP TABLE IF EXISTS headers")
        cursor.execute("DROP TABLE IF EXISTS notes")

        # Создаем таблицу для заметок с поддержкой UTF-8
        cursor.execute('''
            CREATE TABLE notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL COLLATE NOCASE,
                title TEXT NOT NULL COLLATE NOCASE,
                content TEXT NOT NULL COLLATE NOCASE,
                status TEXT NOT NULL CHECK(status IN ('в процессе', 'выполнено', 'отложено')) COLLATE NOCASE,
                created_date TEXT NOT NULL,
                issue_date TEXT NOT NULL
            )
        ''')

        # Создаем таблицу для заголовков
        cursor.execute('''
            CREATE TABLE headers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                note_id INTEGER NOT NULL,
                header_text TEXT NOT NULL COLLATE NOCASE,
                FOREIGN KEY (note_id) REFERENCES notes(id) ON DELETE CASCADE,
                UNIQUE(note_id, header_text)
            )
        ''')

        # Создаем индексы
        cursor.execute('CREATE INDEX idx_notes_username ON notes(username COLLATE NOCASE)')
        cursor.execute('CREATE INDEX idx_notes_status ON notes(status COLLATE NOCASE)')

        connection.commit()
        print("Таблицы успешно созданы")

    except Error as e:
        print(f"Ошибка при создании таблиц: {e}")


def add_test_data(connection):
    """Добавляет тестовые данные в базу"""
    try:
        cursor = connection.cursor()
        current_date = datetime.now().strftime("%d.%m.%Y")

        # Добавляем тестовую заметку
        cursor.execute('''
            INSERT INTO notes (
                username, title, content, status, 
                created_date, issue_date
            ) VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            "Тестовый Пользователь",
            "Тестовая заметка",
            "Это тестовая заметка для проверки работы базы данных",
            "в процессе",
            current_date,
            current_date
        ))

        note_id = cursor.lastrowid

        # Добавляем заголовки для тестовой заметки
        cursor.execute('''
            INSERT INTO headers (note_id, header_text)
            VALUES (?, ?)
        ''', (note_id, "Тестовый заголовок"))

        connection.commit()
        print("Тестовые данные добавлены")

    except Error as e:
        print(f"Ошибка при добавлении тестовых данных: {e}")


def initialize_database():
    """Инициализирует базу данных"""
    # Удаляем старую базу данных, если она существует
    if os.path.exists(DATABASE_PATH):
        os.remove(DATABASE_PATH)
        print("Старая база данных удалена")

    connection = create_connection()
    if connection is not None:
        create_tables(connection)
        add_test_data(connection)
        connection.close()
        print("Инициализация базы данных завершена успешно")
    else:
        print("Ошибка: не удалось создать соединение с базой данных.")


if __name__ == "__main__":
    initialize_database()