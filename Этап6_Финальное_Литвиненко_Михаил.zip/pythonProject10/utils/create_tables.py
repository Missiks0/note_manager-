import sqlite3
import os
from datetime import datetime


def create_database():
    """Создание базы данных и таблиц"""
    # Получаем путь к базе данных
    db_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'notes.db')

    try:
        # Создаем соединение с базой данных
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        # Создаем таблицу notes
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                status TEXT NOT NULL,
                created_date TEXT NOT NULL,
                issue_date TEXT NOT NULL
            )
        """)

        # Создаем таблицу headers
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS headers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                note_id INTEGER NOT NULL,
                header_text TEXT NOT NULL,
                FOREIGN KEY (note_id) REFERENCES notes(id) ON DELETE CASCADE
            )
        """)

        # Создаем индексы
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_notes_username 
            ON notes(username)
        """)

        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_headers_note_id 
            ON headers(note_id)
        """)

        # Добавляем тестовые данные
        current_date = datetime.now().strftime("%d.%m.%Y")

        # Добавляем тестовую заметку
        cursor.execute("""
            INSERT INTO notes (
                username, title, content, status, 
                created_date, issue_date
            ) VALUES (?, ?, ?, ?, ?, ?)
        """, (
            "Test User",
            "Test Note",
            "This is a test note",
            "в процессе",
            current_date,
            current_date
        ))

        note_id = cursor.lastrowid

        # Добавляем тестовый заголовок
        cursor.execute("""
            INSERT INTO headers (note_id, header_text)
            VALUES (?, ?)
        """, (note_id, "Test Header"))

        # Сохраняем изменения
        conn.commit()
        print("База данных успешно создана и заполнена тестовыми данными")

    except sqlite3.Error as e:
        print(f"Ошибка при создании базы данных: {e}")
    finally:
        if conn:
            conn.close()


if __name__ == "__main__":
    # Удаляем существующую базу данных, если она есть
    db_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'notes.db')
    if os.path.exists(db_path):
        os.remove(db_path)
        print("Существующая база данных удалена")

    # Создаем новую базу данных
    create_database()